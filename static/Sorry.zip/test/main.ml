(**tests*)

(** ~~ || TEST PLAN || ~~ Our approach to testing was a mix of glassbox &
    blackbox testing, and manually running the game.

    When we originally did not have a lot implemented yet apart from creating
    the players and pawns (i.e. Player.start_player) and the main skeleton
    (bin/main.ml), we could not play our game in the terminal to test our game
    functionality. Therefore, we developed basic tests to see if our data types
    (player, pawn, initial positions, the number of pawns at start and finish )
    were working and whether the information stored was all correct.

    (( MS1 )) We had the main menu (bin/main.ml) and board (module Board) set
    up, which we tested by running the game in the terminal, which was more
    effective in assessing what we needed to change for user experience at that
    point. It made sense to omit Main from the testing, as the majority of the
    functions were print functions and functions that took in user input, which
    were better tested in the terminal. We also tested board in the terminal
    rather than a test suite, because code-functionality wise, the function we
    needed to test for our board (Board.update_board) was primarily based on
    player movement. The original board (as demonstrated by running our game)
    was working fine.

    (( MS2 )) when it came to implementing the movement of the players
    (Player.go, as well as its many helper functions in the Player module), one
    member took on the implementation of movement, while another member was to
    write test cases for it based on the functionality as we discussed what it
    was meant to do in our team meetings. Therefore, since these tests were not
    done with the code implementation, they were blackbox tests that tested the
    basic valid/invalid moves. We also made corresponding tests for board for
    these moves, to see if the functions in the Board module was properly
    updating.

    As we worked on the movement and the board and debugged our code, we would
    mostly just run the game to see how our code worked in many-step game
    sequences as opposed to the more simplistic test cases. This proved to be
    much more useful, because the way our data types are set up, we can only
    make a board and player(s), run the movement functions as many times as
    needed, and test the final resulting player(s) and board to see if the
    sequence was performed. As our game and board are heavily visual (watching
    players move, get bumped back, and printing all turns in sequence that we
    could scroll to see), we preferred to run the game to see exactly what cases
    and steps were causing bugs. If a pattern was identified, we debugged the
    code, and would try to also create test cases (at that point, these were
    glassbox tests) to verify that our code would always work.

    (( MS3 )) We decided to add special moves (in module Player), which required
    heavy testing, as we significantly altered our original Player.go function
    to accomodate the new moves. (This required changing our original Player.go
    tests) The member that helped implement the special moves wrote the tests
    for them afterwards, to test out all possibilities for the movements (glass
    box testing). The other members would also run the game, note any
    irregularities, and make/suggest test cases for particular scenarios (this
    was more blackbox testing).

    Overall, our testing approach integrated glassbox and blackbox testing, as
    well as manually playing the game to ensure the correctness of our system.
    It was very effective to have all members continuously running the game, as
    we often caught most of our bugs this way. Running the game led to
    debugging, which was verified by our test suite and more game running. Our
    test suite is very comprehensive, as it includes both basic functionality,
    but also a variety of specific examples that were intended to test edge
    cases or different branches of the game movements, based on our
    specifications and our experiences of running the game. *)

open OUnit2
open Game
open Player
open Board

let (p1a : Player.pawn) = { pwn = 'a'; pos = 0 }
let (p1b : Player.pawn) = { pwn = 'b'; pos = 0 }
let (p1c : Player.pawn) = { pwn = 'c'; pos = 0 }
let (p1d : Player.pawn) = { pwn = 'd'; pos = 0 }

let (pl1 : Player.t) =
  { player = 1; pawns = [ p1a; p1b; p1c; p1d ]; start_num = 4; final_num = 0 }

let (p1 : Player.t) = Player.start_player 1
let (p2 : Player.t) = Player.start_player 2
let (p3 : Player.t) = Player.start_player 3
let (p4 : Player.t) = Player.start_player 4

(* go tests *)
(* ( "go test 1 - invalid first move" >:: fun _ -> let p = Player.start_player 1
   in let brd = new_board () in assert_equal ~printer:print_player pl1 (go p 'b'
   5 brd; p) );*)

let brd1 = new_board ()
let go_test1 = start_player 1
let _ = go go_test1 'b' 5 brd1
let brd1_exp = new_board ()

(* ( "go test 2 - valid first move" >:: fun _ -> let p = Player.start_player 1
   in let brd = new_board () in assert_equal ~printer:print_player go_test2 (go
   p 'a' 1 brd; p) );*)
let go_test3 = start_player 1
let _ = go go_test3 'a' 1 brd1

let go_test3_exp =
  {
    player = 1;
    pawns =
      [
        { pwn = 'a'; pos = 5 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 0 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

let brd3_exp =
  let b = new_board () in
  b.(5) <- "1a";
  b

let brd5 = new_board ()
let go_test5 = start_player 1
let _ = go go_test5 'a' 1 brd5
let _ = go go_test5 'c' 2 brd5
let _ = go go_test5 'c' 2 brd5
let _ = go go_test5 'b' 1 brd5

let go_test5_exp =
  {
    player = 1;
    pawns =
      [
        { pwn = 'a'; pos = 5 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 8 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 2;
    final_num = 0;
  }

(* go test 7 *)

let brd7 = new_board ()
let go_test7 = start_player 3
let _ = go go_test7 'b' 1 brd7
let _ = go go_test7 'b' 3 brd7
let _ = go go_test7 'b' 4 brd7
let _ = go go_test7 'c' 1 brd7

let go_test7_exp =
  {
    player = 3;
    pawns =
      [
        { pwn = 'a'; pos = 0 };
        { pwn = 'b'; pos = 42 };
        { pwn = 'c'; pos = 35 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 2;
    final_num = 0;
  }

(* "go test 8 - 1 pawn out, chooses to move that pawn" >:: fun _ -> let p =
   Player.start_player 1 in let brd = new_board () in assert_equal
   ~printer:print_player go_test5 (go p 'a' 1 brd; go p 'a' 2 brd; p) );*)
let brd8 = new_board ()
let go_test8 = start_player 4
let _ = go go_test8 'a' 1 brd8
let _ = go go_test8 'a' 2 brd8

let go_test8_exp =
  {
    player = 4;
    pawns =
      [
        { pwn = 'a'; pos = 52 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 0 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

let brd9 = new_board ()
let go_test9 = start_player 3
let _ = go go_test9 'a' 2 brd8
let _ = go go_test9 'b' 2 brd8
let _ = go go_test9 'c' 2 brd8
let _ = go go_test9 'd' 2 brd8

let go_test9_exp =
  {
    player = 3;
    pawns =
      [
        { pwn = 'a'; pos = 36 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 0 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

(* ( "go test 10 - pawn 2c enters safety zone" >:: fun _ -> let p = go_test6 in
   let brd = new_board () in assert_equal ~printer:print_player go_test7 (go p
   'c' 3 brd; go p 'c' 1 brd; go p 'c' 3 brd; p) );*)

let brd10 =
  let b = new_board () in
  b.(13) <- "2c";
  b

let go_test10 =
  {
    player = 2;
    pawns =
      [
        { pwn = 'a'; pos = 0 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 13 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

let _ = go go_test10 'c' 3 brd10
let _ = go go_test10 'c' 3 brd10
let _ = go go_test10 'c' 3 brd10

let go_test10_exp =
  {
    player = 2;
    pawns =
      [
        { pwn = 'a'; pos = 0 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 66 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

let brd10_exp =
  let b = new_board () in
  b.(66) <- "2c";
  b

let brd11 =
  let b = new_board () in
  b.(15) <- "2c";
  b.(22) <- "2a";
  b

let go_test11 =
  {
    player = 2;
    pawns =
      [
        { pwn = 'a'; pos = 22 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 15 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

(* ( "go test 7 - pawn 2c in safety zone, insufficient roll" >:: fun _ -> let p
   = go_test7 in let brd = new_board () in assert_equal ~printer:print_player
   go_test7 (go p 'c' 1 brd; go p 'c' 2 brd; go p 'c' 3 brd; p) );*)
let brd12 =
  let b = new_board () in
  b.(69) <- "2c";
  b

let go_test12 =
  {
    player = 2;
    pawns =
      [
        { pwn = 'a'; pos = 0 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 69 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

let _ = go go_test12 'c' 3 brd12
let _ = go go_test12 'c' 4 brd12
let _ = go go_test12 'c' 5 brd12

let go_test12_exp =
  {
    player = 2;
    pawns =
      [
        { pwn = 'a'; pos = 0 };
        { pwn = 'b'; pos = 0 };
        { pwn = 'c'; pos = 69 };
        { pwn = 'd'; pos = 0 };
      ];
    start_num = 3;
    final_num = 0;
  }

let brd12_exp =
  let b = new_board () in
  b.(69) <- "2c";
  b

(* board tests *)

let brd1_ans =
  let b = new_board () in
  b.(50) <- "4d";
  b

let brd2 =
  let b = new_board () in
  b.(67) <- "2c";
  b

let pl_list = [ p1; p2; p3; p4 ]

(** [print_player p] is a helper print function that prints out the player
    represented by [p]. Prints out the player number, list of pawns and their
    positions, and the start/final numbers. *)
let print_player p =
  "Player " ^ string_of_int p.player ^ "\n Pawns: " ^ "a: "
  ^ string_of_int (List.nth p.pawns 0).pos
  ^ "; b: "
  ^ string_of_int (List.nth p.pawns 1).pos
  ^ "; c: "
  ^ string_of_int (List.nth p.pawns 2).pos
  ^ "; d: "
  ^ string_of_int (List.nth p.pawns 3).pos
  ^ "\n Start Num: " ^ string_of_int p.start_num ^ "; Final Num: "
  ^ string_of_int p.final_num

(** [print_int n] is a helper print function that prints out the integer
    represented by [n] *)
let print_int n = string_of_int n

(** [print_string s] is a helper print function that prints out the string
    represented by [s] *)
let print_string s = "\"" ^ s ^ "\""

(** [print_brd b] is a helper print function that prints out just the pawns'
    positions on a board [b] with a simple "..." for the rest of the spaces that
    contain " " *)
let print_brd s b =
  for i = 0 to 82 do
    let n = Array.get b i in
    if n = "  " then s := !s ^ "[" ^ string_of_int i ^ "--" ^ "]: "
    else s := !s ^ "[" ^ string_of_int i ^ "]: " ^ n ^ "; "
  done;
  !s

let go_tests =
  [
    ( "go test 1 - pl1 invalid first move" >:: fun _ ->
      assert_equal ~printer:print_player pl1 go_test1 );
    ( "go test 2 - pl1 invalid first move - no overlap" >:: fun _ ->
      let p = Player.start_player 1 in
      let brd = new_board () in
      assert_equal "  " (go p 'b' 5 brd) );
    ( "go test 3 - valid first move" >:: fun _ ->
      assert_equal ~printer:print_player go_test3_exp go_test3 );
    ( "go test 4 - pl1 valid first move - no overlap" >:: fun _ ->
      let p = Player.start_player 1 in
      let brd = new_board () in
      assert_equal "  " (go p 'a' 1 brd) );
    ( "go test 5 - pl1 valid move possible for other pawn but chose invalid"
    >:: fun _ ->
      assert_equal ~printer:print_int go_test5_exp.start_num go_test5.start_num
    );
    ( "go test 6 - pl1 chose invalid - no overlap " >:: fun _ ->
      assert_equal go_test5_exp.start_num go_test5.start_num );
    ( "go test 7 - 2 pawns out, pl3 chooses to move new pawn" >:: fun _ ->
      assert_equal ~printer:print_player go_test7 go_test7_exp );
    ( "go test 8 - 1 pawn out, chooses to move that pawn" >:: fun _ ->
      assert_equal ~printer:print_player go_test8_exp go_test8 );
    ( "go test 9 - pawn at 1, can't move another pawn to 1" >:: fun _ ->
      assert_equal ~printer:print_player go_test9_exp go_test9 );
    ( "go test 10 - pawn 2c enters safety zone" >:: fun _ ->
      assert_equal ~printer:print_player go_test10_exp go_test10 );
    ( "go test 11 - enter safety zone -- no overlap" >:: fun _ ->
      let b = brd11 in
      assert_equal "  " (go go_test11 'c' 5 b) );
    ( "go test 12 - pawn 2c in safety zone, insufficient roll - same pos"
    >:: fun _ ->
      assert_equal ~printer:print_int 69 (List.nth go_test12.pawns 2).pos );
    ( "go test 13 - pawn 2c in safety zone, insufficient roll - same final num"
    >:: fun _ ->
      assert_equal ~printer:print_int go_test12_exp.final_num
        go_test12.final_num );
    ( "go test 14 - pawn 2c in safety zone, insufficient roll - same start num"
    >:: fun _ ->
      assert_equal ~printer:print_int go_test12_exp.start_num
        go_test12.start_num );
  ]

let start_pl_tests =
  [
    ("start player test 1" >:: fun _ -> assert_equal pl1 (Player.start_player 1));
    ( "start player test 2 - player name" >:: fun _ ->
      assert_equal 1 (Player.start_player 1).player );
    ( "start player test 3 - pawn" >:: fun _ ->
      assert_equal 'a' (List.nth (Player.start_player 1).pawns 0).pwn );
    ( "start player test 4 - initial position" >:: fun _ ->
      assert_equal 0 (List.nth (Player.start_player 1).pawns 0).pos );
    ( "start player test 5 - start num" >:: fun _ ->
      assert_equal 4 (Player.start_player 1).start_num );
    ( "start player test 6 - final num" >:: fun _ ->
      assert_equal 0 (Player.start_player 1).final_num );
  ]

let board_tests =
  [
    ( "board test 1 - initial move fail" >:: fun _ ->
      assert_equal ~printer:print_string brd1_exp.(1) brd1.(1) );
    ( "board test 2 - initial move success" >:: fun _ ->
      assert_equal ~printer:print_string brd3_exp.(5) brd1.(5) );
    ( "board test 3 - 2c enters safety zone - og pos " >:: fun _ ->
      assert_equal ~printer:print_string brd10.(19) brd10_exp.(19) );
    ( "board test 4 - 2c enters safety zone - new pos" >:: fun _ ->
      assert_equal ~printer:print_string brd10.(66) brd10_exp.(66) );
    ( "board test 5 - invalid move - 2c stuck in safety zone " >:: fun _ ->
      assert_equal brd12_exp.(69) brd12.(69) );
  ]

(*Special Move Tests*)
let (sp1 : Player.t) = Player.start_player 1
let (sp2 : Player.t) = Player.start_player 2
let (sp3 : Player.t) = Player.start_player 3
let (sp4 : Player.t) = Player.start_player 4
let sp_lst = [ sp1; sp2; sp3; sp4 ]

let _ =
  update_pos sp1 'c' 23;
  sp1.start_num <- sp1.start_num - 1;
  update_pos sp2 'd' 51;
  sp2.start_num <- sp2.start_num - 1;
  update_pos sp3 'a' 11;
  update_pos sp3 'd' 82;
  sp3.start_num <- sp3.start_num - 1;
  sp3.final_num <- 1;
  update_pos sp4 'a' 4;
  update_pos sp4 'c' 44;
  sp4.start_num <- sp4.start_num - 2

let dummy_board = new_board ()

let swap_test (name : string) (my_pl : t) (my_pwn : char) (oth_pl : t)
    (oth_pwn : char) (brd : string array) (out1 : int) (out2 : int) : test =
  name >:: fun _ ->
  assert_equal (out1, out2)
    (Player.swap my_pl my_pwn oth_pl oth_pwn brd;
     (pwn_pos my_pl my_pwn, pwn_pos oth_pl oth_pwn))

let back_st_test (name : string) (pl : t) (pwn : char) brd (out1 : int)
    (st_num_out : int) : test =
  name >:: fun _ ->
  assert_equal (out1, st_num_out)
    (Player.back_st pl pwn brd;
     (pwn_pos pl pwn, pl.start_num))

let to_fin_test (name : string) (pl : t) (pwn : char) brd (out1 : int)
    (st_num_out : int) : test =
  name >:: fun _ ->
  assert_equal (out1, st_num_out)
    (Player.to_fin pl pwn brd;
     (pwn_pos pl pwn, pl.final_num))

let special_tests =
  [
    swap_test "Swap 1c 23 with 2d 51" sp1 'c' sp2 'd' dummy_board 51 23;
    swap_test "Swap 3a 11 with 4a 4" sp3 'a' sp4 'a' dummy_board 4 11;
    back_st_test "1c back to start" sp1 'c' dummy_board 0 4;
    back_st_test "4a back to start" sp4 'a' dummy_board 0 3;
    to_fin_test "2d to finish" sp2 'd' dummy_board 82 1;
    to_fin_test "3a to finish" sp3 'a' dummy_board 82 2;
  ]

let (mp1 : Player.t) = Player.start_player 1
let (mp2 : Player.t) = Player.start_player 2
let (mp3 : Player.t) = Player.start_player 3
let (mp4 : Player.t) = Player.start_player 4
let mp_lst = [ mp1; mp2; mp3; mp4 ]
let mp_board = new_board ()

(*player 1*)
let _ = Player.go mp1 'a' 2 mp_board
let _ = update_pos mp1 'b' 6
let _ = Player.go mp1 'b' 4 mp_board
let _ = update_pos mp1 'c' 59
let _ = Player.go mp1 'c' 6 mp_board
let _ = update_pos mp1 'd' 3
let _ = Player.go mp1 'd' 6 mp_board

(*player 2*)
let _ = Player.go mp2 'a' 1 mp_board
let _ = update_pos mp2 'b' 30
let _ = Player.go mp2 'b' 4 mp_board
let _ = update_pos mp2 'c' 15
let _ = Player.go mp2 'c' 4 mp_board
let _ = update_pos mp2 'd' 18
let _ = Player.go mp2 'd' 6 mp_board

(*player 3*)
let _ = Player.go mp3 'a' 2 mp_board
let _ = update_pos mp3 'b' 51
let _ = Player.go mp3 'b' 2 mp_board
let _ = update_pos mp3 'c' 30
let _ = Player.go mp3 'c' 5 mp_board
let _ = update_pos mp3 'd' 71
let _ = Player.go mp3 'd' 5 mp_board

(*player 4*)
let _ = Player.go mp4 'a' 1 mp_board
let _ = update_pos mp4 'b' 59
let _ = Player.go mp4 'b' 1 mp_board
let _ = update_pos mp4 'c' 47
let _ = Player.go mp4 'c' 3 mp_board
let _ = update_pos mp4 'd' 79
let _ = Player.go mp4 'd' 2 mp_board

let movement_test (name : string) (t : t) (c : char) (out : int) : test =
  name >:: fun _ -> assert_equal out (pwn_pos t c) ~printer:string_of_int

let movement_tests =
  [
    (*player 1*)
    movement_test "move 1a out of home 2 spaces" mp1 'a' 6;
    movement_test "move 1b from 6, 4 spaces to 10, regular move" mp1 'b' 10;
    movement_test "move 1c from 59, 6 spaces to 62, into safety zone" mp1 'c' 62;
    movement_test "move 1d from 3, 6 spaces to finish" mp1 'd' 82;
    (*player 2*)
    movement_test "move 2a out of home 1 space" mp2 'a' 20;
    movement_test "move 2b from 30, 4 spaces to 34, regular move" mp2 'b' 34;
    movement_test "move 2c from 15, 4 spaces to 66, into safety zone" mp2 'c' 66;
    movement_test "move 2d from 18, 6 spaces to finish" mp2 'd' 82;
    (*player 3*)
    movement_test "move 3a out of home 2 spaces" mp3 'a' 36;
    movement_test "move 3b from 51, 2 spaces to 53, regular move" mp3 'b' 53;
    movement_test "move 3c from 30, 5 spaces to 72, into safety zone" mp3 'c' 72;
    movement_test "move 3d from 71, 5 spaces to finish" mp3 'd' 82;
    (*player 4*)
    movement_test "move 4a out of home 1 space1" mp4 'a' 50;
    movement_test "move 4b from 59, 1 space to 60, regular move" mp4 'b' 60;
    movement_test "move 4c from 47, 3 spaces to 77, into safety zone" mp4 'c' 77;
    movement_test "move 4d from 79, 2 spaces to finish" mp4 'd' 82;
  ]

let (hp1 : Player.t) = Player.start_player 1
let (hp2 : Player.t) = Player.start_player 2
let (hp3 : Player.t) = Player.start_player 3
let (hp4 : Player.t) = Player.start_player 4
let hp_lst = [ hp1; hp2; hp3; hp4 ]
let hp_board = new_board ()

let _ =
  update_pos hp2 'a' 2;
  update_pos hp2 'c' 44;
  go_home hp2 'd'

let pl_num_test (name : string) (t : t) (out : int) : test =
  name >:: fun _ -> assert_equal out (Player.pl_num t)

let pwn_pos_test (name : string) (t : t) (c : char) (out : int) : test =
  name >:: fun _ -> assert_equal out (Player.pwn_pos t c)

let pl_name_test (name : string) (t : t) (c : char) (out : string) : test =
  name >:: fun _ -> assert_equal out (Player.pl_name t c)

let help_fun_tests =
  [
    pl_num_test "Player 1 number" hp1 1;
    pl_num_test "Player 2 number" hp2 2;
    pl_num_test "Player 3 number" hp3 3;
    pl_num_test "Player 4 number" hp4 4;
    pwn_pos_test "2c is at position 44" hp2 'c' 44;
    pwn_pos_test "2d is at position 82" hp2 'd' 82;
    pwn_pos_test "3d is at position 0" hp3 'd' 0;
    pl_name_test "Player 1, pawn c is '1c'" hp1 'c' "1c";
    pl_name_test "Player 4, pawn d is '4d'" hp4 'd' "4d";
  ]

let suite =
  "search test suite"
  >::: List.flatten
         [
           go_tests;
           start_pl_tests;
           board_tests;
           special_tests;
           movement_tests;
           help_fun_tests;
         ]

let _ = run_test_tt_main suite
