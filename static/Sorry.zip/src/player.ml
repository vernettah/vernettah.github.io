open Board

exception UnknownPlayer of int
exception UnknownPawn of char
exception InvalidMove

type pawn = {
  pwn : char;
  mutable pos : int;
}

type t = {
  player : int;
  pawns : pawn list;
  mutable start_num : int;
  mutable final_num : int;
}

let pl_num p = p.player

let pwn_pos t c =
  match c with
  | 'a' -> (List.nth t.pawns 0).pos
  | 'b' -> (List.nth t.pawns 1).pos
  | 'c' -> (List.nth t.pawns 2).pos
  | 'd' -> (List.nth t.pawns 3).pos
  | _ -> raise (UnknownPawn c)

let pl_name p c = string_of_int p.player ^ Char.escaped c
let start_pwns p = p.start_num
let fin_pwns p = p.final_num

let start_player p =
  if p == 1 || p == 2 || p == 3 || p == 4 then
    {
      player = p;
      pawns =
        [
          { pwn = 'a'; pos = 0 };
          { pwn = 'b'; pos = 0 };
          { pwn = 'c'; pos = 0 };
          { pwn = 'd'; pos = 0 };
        ];
      start_num = 4;
      final_num = 0;
    }
  else raise (UnknownPlayer p)

let roll t =
  if start_pwns t = 4 then Random.int 3 + 1
  else
    let base_roll = Random.int 19 + 1 in
    if base_roll >= 19 then 1
    else if base_roll >= 17 then 2
    else if base_roll mod 10 = 0 then 10
    else if base_roll mod 10 = 9 then
      let prob = Random.int 6 + 1 in
      if prob = 7 then 9 else prob
    else base_roll mod 10

let print_roll r =
  match r with
  | 7 -> print_endline "You have rolled: 7 - Wild Card!\n"
  | 8 -> print_endline "You have rolled: 8 - Your turn has been skipped.\n"
  | 9 -> print_endline "You have rolled: 9 - Back to Start! \n"
  | 10 -> print_endline "You have rolled: 10 - Speed to Finish!\n"
  | _ -> print_endline ("You have rolled: " ^ string_of_int r ^ "\n")

let check_tpawns (t : t) (p : int) =
  (not (pwn_pos t 'a' = p))
  && (not (pwn_pos t 'b' = p))
  && (not (pwn_pos t 'c' = p))
  && not (pwn_pos t 'c' = p)

let update_pos t c (p : int) =
  match c with
  | 'a' -> (List.nth t.pawns 0).pos <- p
  | 'b' -> (List.nth t.pawns 1).pos <- p
  | 'c' -> (List.nth t.pawns 2).pos <- p
  | 'd' -> (List.nth t.pawns 3).pos <- p
  | _ -> raise (UnknownPawn c)

let update_check t c (np : int) =
  if check_tpawns t np then update_pos t c np
  else print_endline "Invalid move. You already have a pawn here!"

let regular_move t (c : char) (r : int) =
  (let modval = (pwn_pos t c + r) mod 60 in
   if modval = 0 then 60 else modval)
  |> update_check t c

let move_start t (c : char) (r : int) =
  match pl_num t with
  | 1 ->
      5 + r - 1 |> update_check t c;
      if pwn_pos t c = 5 + r - 1 then t.start_num <- t.start_num - 1
  | 2 ->
      20 + r - 1 |> update_check t c;
      if pwn_pos t c = 20 + r - 1 then t.start_num <- t.start_num - 1
  | 3 ->
      35 + r - 1 |> update_check t c;
      if pwn_pos t c = 35 + r - 1 then t.start_num <- t.start_num - 1
  | 4 ->
      50 + r - 1 |> update_check t c;
      if pwn_pos t c = 50 + r - 1 then t.start_num <- t.start_num - 1
  | _ -> raise (UnknownPlayer (pl_num t))

let go_home t (c : char) =
  update_pos t c 82;
  t.final_num <- t.final_num + 1

let player1_move t c r =
  if pwn_pos t c = 58 || pwn_pos t c = 59 || pwn_pos t c = 60 then
    if pwn_pos t c + r >= 64 then update_check t c (pwn_pos t c + r - 3)
    else regular_move t c r
  else if pwn_pos t c = 1 || pwn_pos t c = 2 || pwn_pos t c = 3 then
    if
      (pwn_pos t c = 1 && r = 1)
      || (pwn_pos t c = 1 && r = 2)
      || (pwn_pos t c = 2 && r = 1)
    then update_check t c (pwn_pos t c + r)
    else if pwn_pos t c = 3 && r = 6 then go_home t c
    else update_check t c (pwn_pos t c + r + 57)
  else if
    pwn_pos t c = 61
    || pwn_pos t c = 62
    || pwn_pos t c = 63
    || pwn_pos t c = 64
    || pwn_pos t c = 65
  then
    if pwn_pos t c + r = 66 then go_home t c
    else print_endline "You can not move this pawn."
  else regular_move t c r

let player2_move t c r =
  if
    (pwn_pos t c = 55
    || pwn_pos t c = 56
    || pwn_pos t c = 57
    || pwn_pos t c = 58
    || pwn_pos t c = 59
    || pwn_pos t c = 60)
    && pwn_pos t c + r >= 61
  then update_check t c (pwn_pos t c + r - 60)
  else if
    (pwn_pos t c = 13
    || pwn_pos t c = 14
    || pwn_pos t c = 15
    || pwn_pos t c = 16
    || pwn_pos t c = 17
    || pwn_pos t c = 18)
    && pwn_pos t c + r >= 19
  then
    if
      (pwn_pos t c = 16 && r = 1)
      || (pwn_pos t c = 16 && r = 2)
      || (pwn_pos t c = 17 && r = 1)
    then update_check t c (pwn_pos t c + r)
    else if pwn_pos t c = 18 && r = 6 then go_home t c
    else update_check t c (pwn_pos t c + r + 47)
  else if
    pwn_pos t c = 66
    || pwn_pos t c = 67
    || pwn_pos t c = 68
    || pwn_pos t c = 69
    || pwn_pos t c = 70
  then
    if pwn_pos t c + r = 71 then go_home t c
    else print_endline "Invalid move for this pawn. "
  else regular_move t c r

let player3_move t c r =
  if
    (pwn_pos t c = 55
    || pwn_pos t c = 56
    || pwn_pos t c = 57
    || pwn_pos t c = 58
    || pwn_pos t c = 59
    || pwn_pos t c = 60)
    && pwn_pos t c + r >= 61
  then update_check t c (pwn_pos t c + r - 60)
  else if
    (pwn_pos t c = 28
    || pwn_pos t c = 29
    || pwn_pos t c = 30
    || pwn_pos t c = 31
    || pwn_pos t c = 32
    || pwn_pos t c = 33)
    && pwn_pos t c + r >= 34
  then
    if
      (pwn_pos t c = 31 && r = 1)
      || (pwn_pos t c = 31 && r = 2)
      || (pwn_pos t c = 32 && r = 1)
    then update_check t c (pwn_pos t c + r)
    else if pwn_pos t c = 33 && r = 6 then go_home t c
    else update_check t c (pwn_pos t c + r + 37)
  else if
    pwn_pos t c = 71
    || pwn_pos t c = 72
    || pwn_pos t c = 73
    || pwn_pos t c = 74
    || pwn_pos t c = 75
  then
    if pwn_pos t c + r = 76 then go_home t c
    else print_endline "Invalid move for this pawn."
  else regular_move t c r

let player4_move t c r =
  if
    (pwn_pos t c = 55
    || pwn_pos t c = 56
    || pwn_pos t c = 57
    || pwn_pos t c = 58
    || pwn_pos t c = 59
    || pwn_pos t c = 60)
    && pwn_pos t c + r >= 61
  then update_check t c (pwn_pos t c + r - 60)
  else if
    (pwn_pos t c = 43
    || pwn_pos t c = 44
    || pwn_pos t c = 45
    || pwn_pos t c = 46
    || pwn_pos t c = 47
    || pwn_pos t c = 48)
    && pwn_pos t c + r >= 49
  then
    if
      (pwn_pos t c = 46 && r = 1)
      || (pwn_pos t c = 46 && r = 2)
      || (pwn_pos t c = 47 && r = 1)
    then update_check t c (pwn_pos t c + r)
    else if pwn_pos t c = 48 && r = 6 then go_home t c
    else update_check t c (pwn_pos t c + r + 27)
  else if
    pwn_pos t c = 76
    || pwn_pos t c = 77
    || pwn_pos t c = 78
    || pwn_pos t c = 79
    || pwn_pos t c = 80
  then
    if pwn_pos t c + r = 81 then go_home t c
    else print_endline "Invalid move for this pawn."
  else regular_move t c r

let print_message c s =
  ANSITerminal.print_string [ c ]
    ("\n\n [" ^ s ^ "] has been bumped back to start!\n")

let rec sorry_start (t : t list) (s : string) =
  let index = int_of_char s.[0] - 48 in
  let t_pl = List.nth t (index - 1) in
  update_pos t_pl s.[1] 0;
  t_pl.start_num <- t_pl.start_num + 1;

  match index with
  | 1 -> print_message ANSITerminal.red s
  | 2 -> print_message ANSITerminal.blue s
  | 3 -> print_message ANSITerminal.yellow s
  | 4 -> print_message ANSITerminal.green s
  | _ -> ()

let go (t : t) (c : char) (r : int) (brd : string array) =
  let og_ps = pwn_pos t c in
  (if pwn_pos t c = 0 then
   if r = 1 || r = 2 then move_start t c r
   else print_endline "You must roll a 1 or 2 to move out of Home."
  else
    match pl_num t with
    | 1 -> player1_move t c r
    | 2 -> player2_move t c r
    | 3 -> player3_move t c r
    | 4 -> player4_move t c r
    | _ -> raise (UnknownPlayer (pl_num t)));

  let repl = Board.update_board brd (pl_name t c) og_ps (pwn_pos t c) in
  if String.equal (string_of_int (pl_num t)) (Char.escaped repl.[0]) then "  "
  else if pwn_pos t c = 82 then "  "
  else repl

let swap (my_pl : t) (my_pwn : char) (oth_pl : t) (oth_pwn : char) brd =
  let my_temp = pwn_pos my_pl my_pwn in
  let oth_temp = pwn_pos oth_pl oth_pwn in
  update_pos my_pl my_pwn oth_temp;
  update_pos oth_pl oth_pwn my_temp;
  Board.swap_board brd my_temp oth_temp

let back_st (pl : t) (pwn : char) brd =
  let og_ps = pwn_pos pl pwn in
  update_pos pl pwn 0;
  pl.start_num <- pl.start_num + 1;
  Board.up_board brd
    (string_of_int (pl_num pl) ^ Char.escaped pwn)
    og_ps (pwn_pos pl pwn)

let to_fin pl pwn brd =
  let og_ps = pwn_pos pl pwn in
  update_pos pl pwn 82;
  pl.final_num <- pl.final_num + 1;
  Board.up_board brd
    (string_of_int (pl_num pl) ^ Char.escaped pwn)
    og_ps (pwn_pos pl pwn)

let at_start t =
  if start_pwns t = 0 then
    "Player " ^ string_of_int (pl_num t) ^ " has no pawns at start\n"
  else
    let s =
      ref ("Player " ^ string_of_int (pl_num t) ^ "'s pawns at start: ")
    in
    if pwn_pos t 'a' = 0 then s := !s ^ "a ";
    if pwn_pos t 'b' = 0 then s := !s ^ "b ";
    if pwn_pos t 'c' = 0 then s := !s ^ "c ";
    if pwn_pos t 'd' = 0 then s := !s ^ "d ";
    s := !s ^ "\n";
    !s
