let rd = ANSITerminal.red
let grn = ANSITerminal.green
let bl = ANSITerminal.blue
let yl = ANSITerminal.yellow
let wh = ANSITerminal.white
let pr_c cl txt = ANSITerminal.print_string [ cl ] txt

let rec numdash str c =
  match c - 1 with
  | 0 -> str
  | _ -> numdash (str ^ "-") (c - 1)

let dash c = numdash "-" c
let one_dash = "----"

let rec numspace str c =
  match c - 1 with
  | 0 -> str
  | _ -> numspace (str ^ " ") (c - 1)

let space c = numspace " " c

let pr_pos pos =
  match pos.[0] with
  | '1' -> pr_c rd pos
  | '2' -> pr_c bl pos
  | '3' -> pr_c yl pos
  | '4' -> pr_c grn pos
  | _ -> print_string pos

let brick x =
  print_string "| ";
  pr_pos x;
  print_string " |"

let br x = "| " ^ x ^ " |"

let rec hor lst (p : string array) c =
  for i = 0 to List.length lst - 1 do
    ANSITerminal.print_string [ c ] "| ";
    pr_pos (p.(List.nth lst i) ^ " ")
  done

let print_board (p : string array) sf =
  print_string ("\n " ^ dash 79 ^ "\n");
  hor [ 1; 2; 3; 4; 5; 6; 7; 8; 9; 10; 11; 12; 13; 14; 15; 16 ] p wh;
  print_string ("|\n " ^ dash 79 ^ "\n");
  brick p.(60);
  print_string (space 4);
  pr_c rd (br p.(61) ^ "    { " ^ sf.(0) ^ " }" ^ space 49);
  brick p.(17);
  print_string ("\n " ^ one_dash ^ space 6);
  pr_c rd (one_dash ^ space 6 ^ "====");
  pr_c bl (space 21 ^ "==== " ^ dash 24);
  print_string (dash 5 ^ "\n");
  brick p.(59);
  pr_c rd (space 4 ^ br p.(62) ^ space 29);
  pr_c bl ("{ " ^ sf.(5) ^ space 1);
  hor [ 70; 69; 68; 67; 66 ] p bl;
  hor [ 18 ] p wh;
  print_string ("|\n " ^ one_dash ^ space 6);
  pr_c rd (one_dash ^ space 31);
  pr_c bl ("==== " ^ dash 24);
  print_string (dash 5 ^ "\n");
  brick p.(58);
  pr_c rd (space 4 ^ br p.(63) ^ space 59);
  brick p.(19);
  print_string ("\n " ^ one_dash ^ space 6);
  pr_c rd (one_dash ^ space 56);
  pr_c bl "==== ";
  print_string (one_dash ^ "\n");
  brick p.(57);
  pr_c rd (space 4 ^ br p.(64) ^ space 54);
  pr_c bl ("{ " ^ sf.(1) ^ " ");
  brick p.(20);
  print_string ("\n " ^ one_dash ^ space 6);
  pr_c rd (one_dash ^ space 56);
  pr_c bl "==== ";
  print_string (one_dash ^ "\n");
  brick p.(56);
  pr_c rd (space 4 ^ br p.(65) ^ space 59);
  brick p.(21);
  print_string ("\n " ^ one_dash ^ space 6);
  pr_c rd (one_dash ^ space 61);
  print_string (one_dash ^ "\n");
  brick p.(55);
  pr_c rd (space 4 ^ "{ " ^ sf.(4) ^ " }" ^ space 59);
  brick p.(22);
  print_string ("\n " ^ one_dash ^ space 6);
  pr_c rd "====";
  print_string (space 61 ^ one_dash ^ "\n");
  brick p.(54);
  print_string (space 69);
  brick p.(23);
  print_string ("\n " ^ one_dash ^ space 71 ^ one_dash ^ "\n");
  brick p.(53);
  print_string (space 69);
  brick p.(24);
  print_string ("\n " ^ one_dash ^ space 61);
  pr_c yl "====";
  print_string (space 6 ^ one_dash ^ "\n");
  brick p.(52);
  pr_c yl (space 59 ^ "{ " ^ sf.(6) ^ " }    ");
  brick p.(25);
  print_string ("\n " ^ one_dash ^ space 61);
  pr_c yl (one_dash ^ space 6);
  print_string (one_dash ^ "\n");
  brick p.(51);
  pr_c yl (space 59 ^ br p.(75) ^ space 4);
  brick p.(26);
  print_string ("\n " ^ one_dash ^ space 1);
  pr_c grn "====";
  pr_c yl (space 56 ^ one_dash ^ space 6);
  print_string (one_dash ^ "\n");
  brick p.(50);
  pr_c grn (" " ^ sf.(3) ^ " }" ^ space 54);
  pr_c yl (br p.(74) ^ space 4);
  brick p.(27);
  print_string ("\n " ^ one_dash ^ space 1);
  pr_c grn "====";
  pr_c yl (space 56 ^ one_dash ^ space 6);
  print_string (one_dash ^ "\n");
  brick p.(49);
  pr_c yl (space 59 ^ br p.(73) ^ space 4);
  brick p.(28);
  print_string ("\n " ^ dash 5);
  pr_c grn (dash 24 ^ " ====" ^ space 31);
  pr_c yl one_dash;
  print_string (space 6 ^ one_dash ^ "\n");
  brick p.(48);
  pr_c grn (space 1 ^ p.(76) ^ space 1);
  hor [ 77; 78; 79; 80 ] p grn;
  pr_c grn ("| " ^ sf.(7) ^ " }");
  pr_c yl (space 29 ^ br p.(72) ^ space 4);
  brick p.(29);
  print_string ("\n " ^ dash 5);
  pr_c grn (dash 24 ^ " ====" ^ space 21);
  pr_c yl ("====      " ^ one_dash ^ space 6);
  print_string (one_dash ^ "\n");
  brick p.(47);
  pr_c yl (space 49 ^ "{ " ^ sf.(2) ^ " }    " ^ br p.(71) ^ space 4);
  brick p.(30);
  print_string ("\n " ^ dash 79 ^ "\n");
  hor [ 46; 45; 44; 43; 42; 41; 40; 39; 38; 37; 36; 35; 34; 33; 32; 31 ] p wh;
  print_string ("|\n " ^ dash 79 ^ "\n")

let new_board () = Array.make 83 "  "

let update_board (brd : string array) str o n =
  brd.(o) <- "  ";
  let repl = brd.(n) in
  brd.(n) <- str;
  repl

let swap_board brd my_pos oth_pos =
  let temp = brd.(my_pos) in
  brd.(my_pos) <- brd.(oth_pos);
  brd.(oth_pos) <- temp

let up_board (brd : string array) str o n =
  brd.(o) <- "  ";
  brd.(n) <- str
